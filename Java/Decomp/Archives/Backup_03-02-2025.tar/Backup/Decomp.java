import java.io.BufferedReader;
import java.io.FileReader;
import java.nio.file.* ;

public class Decomp {
    // TODO : cataLoad (loads recipes from a GRDA-formatted file and creates a catalog
    // TODO : getMain (loads the recipe of the main item)
    // TODO : based (checks if the mainRecipe is made of base items)

    public static boolean cataLoaded = false ;

    public static void loadError() {
        System.out.println("Error while loading the recipes from the file !");
        System.exit(1);
    }

    public static void cataLoad(String fileName) {
        try {
            BufferedReader br = new BufferedReader(new FileReader(fileName));
            String line = br.readLine() ;
            while (line != null) {
                evalLine()
            }
            cataLoaded = true ;
            br.close();
        } catch (Exception e) {
            loadError();
        }
    }

    public static void main (String[] args) {
        String goal = args[0] ;
        String filePath = args[1] ;
        Recipe[] catalog = cataLoad(filePath) ; // This line loads recipes from a GRDA-formatted file and creates a catalog
        Recipe mainRecipe = getMain(catalog , goal) ;
        while (!(based(mainRecipe))) {
            
        }
    }
}