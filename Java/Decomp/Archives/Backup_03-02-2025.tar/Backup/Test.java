public class Test {
    public static void main (String[] args) {
        System.out.println(Recipe.readRecipe("GP=RD+5GJ+3EGB")) ;
    }
}