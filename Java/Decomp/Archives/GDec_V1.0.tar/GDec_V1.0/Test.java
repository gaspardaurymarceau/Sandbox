public class Test {
    public static void main (String[] args) {
        System.out.println(Recipe.readRecipe("GP=1RD+5GJ+3EGB")) ;
        int x = 2 ;
        System.out.println(++x) ;
        System.out.println(x) ;
    }
}